<?php

class Crudops extends CI_Model{
	public function retData()
	{
		return ['xyz'=>"XYZ",'abc'=>"ABC"];
	}
	public function retFromDb()
	{
		$q = $this->db->get('users');


		if($q->num_rows())	
		{
			return $q->result_array();
		}
		else{
			echo "no record found";
		}
				
	}
	public function checkData($data)
	{
		$q = $this->db->where('uname',$data['username'])
						->where('pass',$data['password'])
						->get('users');

		return $q->result_array();
	}
	public function valid_username($str)
	{
		$this->db->where('uname',$str)
					->get('users');
	}
	public function valid_password($str)
	{
		$this->db->where('pword',$str)
					->get('users');
	}
	public function insertData($data)
	{
		//$data = array('uname'=>'uname','pass'=>'pass','fname'=>'fname','lname'=>'lname');
		$this->db->insert('users',$data);

		//return $q;
	}
	public function daleteData($id)
	{
		$this->db->delete('users',$id);
	}
}