<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Delete extends MY_Controller {

	public function deleteData($id)
	{
		echo "deleted!";

	}
}