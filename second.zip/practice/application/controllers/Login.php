<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends MY_Controller {
	
		public $submittedData = $this->input->post()?$this->input->post():array(false);

        public $datacheck = array(
                'uname'=>$submittedData['username'],
                'pword'=>$submittedData['password'],
        );

	public function index()
	{
		$this->load->view('header');
		
		$this->load->view('login');

		$this->load->view('footer');		
	}
	public function checkData()
	{

        $this->form_validation->set_rules('username', 'Username', 
        	array('required',
        		array($this->crudops,'valid_username')
        	));//|callback_username_check');
        $this->form_validation->set_rules('password','Password', 
        	array('required',
        		array($this->crudops,'valid_password')
        	); //|callback_password_check');
                
        if(array_key_exists('submit', $submittedData))
        {
                if ($this->form_validation->run() === FALSE)
                {
                        $this->load->view('header');                 
                        $this->load->view('login');
                        $this->load->view('footer');
                }
                else
                {                        
 
                    $this->crudops->checkData($datacheck);
                    redirect('home');
                }                   
        }
	}
	public function username_check($str)
	{
		if($str === strtolower($datacheck['uname']))
		{
			return true;
		}
	}
}