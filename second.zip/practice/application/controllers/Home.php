<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends MY_Controller {
	public function index()
	{
		

		$this->load->view('header');

		$data['users'] = $this->crudops->retFromDb();

		$this->load->view('listdata',$data);
		
		
		$this->load->view('footer');
	}
}