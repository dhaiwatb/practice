<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Insert extends MY_Controller {
	public function index()
	{
                $this->load->view('header');

                $this->load->view('insert');

                $this->load->view('footer');
	}
        
        
        public function checkData()
        {
                $submittedData = $this->input->post()?$this->input->post():array(false);

                $dataInsert = array(
                        'uname'=>$submittedData['username'],
                        'pword'=>$submittedData['password'],
                        'fname'=>$submittedData['firstname'],
                        'lname'=>$submittedData['lastname']
                );

                $this->form_validation->set_rules('username', 'Username', 'required|is_unique[users.uname]');
                $this->form_validation->set_rules('password', 'Password', 'required');
                $this->form_validation->set_rules('firstname', 'First name', 'required|alpha');
                $this->form_validation->set_rules('lastname', 'Last name', 'required|alpha');
                        
                if(array_key_exists('submit', $submittedData))
                {
                        if ($this->form_validation->run() === FALSE)
                        {
                                $this->load->view('header');                 
                                $this->load->view('insert');
                                $this->load->view('footer');
                        }
                        else
                        {
                        
                                $this->crudops->insertData($dataInsert);
                                redirect('home');
                        }                   
                }
        }
}