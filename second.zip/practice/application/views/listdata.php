
<div class="bs-docs-section">
    <div class="row">
    	<div class="col-lg-12">
            <div class="page-header">
				<h1 id="tables">User Informations</h1>
            </div>

            <div class="bs-component">
				<table class="table">
					<thead>
						<tr>
				      		<th scope="col">Username</th>
				      		<th scope="col">Password</th>
				      		<th scope="col">Actions</th>	
				    	</tr>
					</thead>
					<?php foreach($users as $user): ?>
					
					<tbody>
						<tr>
							<td><?= $user['uname'] ?></td>
							<td><?= $user['pword'] ?></td>
							<td>
								<a href="<?= base_url('index.php/insert') ?>" class="btn btn-primary">Edit</a>
								<a href="<?= base_url('index.php/home/deleteData') ?>" class="btn btn-danger">Delete</a>
							</td>
						</tr>
					</tbody>
					<?php endforeach;	?>
				</table>
			</div>
		</div>
	</div>
</div>
