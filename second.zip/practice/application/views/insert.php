<?php 

	$attributes = array('class'=>'myform','id'=>'','name'=>'insertForm');
	$id = 0;

  

	$formInputs = array(
		'username'=>array(
			'name'  => 'username',
			'class'=>'form-control',
			set_value('username'),
      'placeholder'=>'Enter Username'
		),
        'password'=>array(
        	'name'  => 'password',
        	set_value('password'),
        	'class'=>'form-control',
        	'placeholder'=>'Enter Password'
        ),
        'firstname'=>array(
        	'name'  => 'firstname',
        	set_value('firstname'),
        	'class'=>'form-control',
          'placeholder'=>'Enter First name'
        ),
        'lastname'=>array(
        	'name'  => 'lastname',
        	set_value('lastname'),
        	'class'=>'form-control',
          'placeholder'=>'Enter Last name'
        )
    );
?>

<div class="col-lg-6">
  <div class="bs-component">
    <?= form_open('insert/checkData',$attributes) ?>
    <fieldset>
      <legend>Sign up</legend>
      <div class="form-group row">
        <label class="col-sm-4 col-form-label">Username</label>
        <div class="col-sm-10">
      	 <?php echo form_input($formInputs['username']); ?>
        </div>
        <div class="col-sm-10">
          <?= form_error('username') ?>
        </div>
      </div>
      <div class="form-group row">
        <label class="col-sm-4 col-form-label">Password</label>
        <div class="col-sm-10">
          <?php echo form_password($formInputs['password']); ?>
        </div>
        <div class="col-sm-10">
          <?= form_error('password') ?>
        </div>
      </div>
      <div class="form-group row">
        <label class="col-sm-4 col-form-label">First name</label>
        <div class="col-sm-10">
          <?php echo form_input($formInputs['firstname']); ?>
        </div>
        <div class="col-sm-10">
          <?= form_error('firstname') ?>
        </div>
      </div>
	    <div class="form-group row">
        <label class="col-sm-4 col-form-label">Last name</label>
        <div class="col-sm-10">
          <?php echo form_input($formInputs['lastname']); ?>
        </div>
        <div class="col-sm-10">
            <?= form_error('lastname') ?>
        </div>
      </div>
      <div class="form-group row">
        <div class="col-sm-10">
          <?= form_submit('submit', 'Submit','class="btn btn-primary"') ?>
          <?= form_reset('reset', 'Clean','class="btn btn-danger"') ?>
          <?=  form_close() ?>
        </div>
      </div>
    </fieldset>
  </div>
</div>    
  

