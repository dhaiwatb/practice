<?php 
	$data = array(
		'username'=>array(
			'name'=>'username',
			'class'=>'form-control',
			set_value('username'),
			'rules'=>'required',
			'placeholder'=>'Enter Username'),
		'password'=>array('name'=>'password',
			'class'=>'form-control',
			set_value('password'),
			'rules'=>'required',
			'placeholder'=>'Enter Password')
	);
?>

<div class="col-lg-6">
      <div class="bs-component">
        <?= form_open('login/checkData',array('class'=>'login','name'=>'loginForm')) ?>
          <fieldset>
            <legend>Login</legend>
            <div class="form-group row">
              <label for="staticEmail" class="col-sm-4 col-form-label">Username</label>
              <div class="col-sm-10">
            	<?php echo form_input($data['username']); ?>
              
            </div>
            <div class="col-sm-10">
              <?= form_error('username') ?>
            </div>
          </div>
      	  <div class="form-group row">
            <label for="staticEmail" class="col-sm-4 col-form-label">Password</label>
            <div class="col-sm-10">
              <?php echo form_password($data['password']); ?>
            </div>
            <div class="col-sm-10">
              <?= form_error('password') ?>
            </div>
          </div>
          <div class="form-group row">
      		<div class="col-sm-10">
      			<?php echo form_submit('submit', 'Submit','class="btn btn-primary"'); ?>
				    <?php echo form_reset('reset','Clear','class="btn btn-danger"'); ?>		
      		</div>
          </div>
          </fieldset>
          <?= form_close() ?>
      </div>
  </div>

