<?php include('inc/header.php'); ?>
	<div class="col-lg-6">
		<form action="logincheck.php" method="post">
			<table class="table">
				<legend>Login for Users</legend>

				<tbody>
					<tr>
						<td><input class="form-control" type="text" name="username" placeholder="Enter username"></td>
					</tr>
					<tr>
						<td><input class="form-control" type="password" name="password" placeholder="Enter password"></td> 
					</tr>
					<tr>
						<td>
							<select name="usertype" class="form-control">
								<option value="">Select user</option>
								<option value="student">Student</option>
								<option value="teacher">Teacher</option>
							</select>
						</td>
					</tr>
					<tr>
						<td><input type="submit" name="submit" class="btn btn-primary" value="Submit"></td>
					</tr>
				</tbody>
			</table>
		</form>	
	</div>
<?php include('inc/footer.php'); ?>