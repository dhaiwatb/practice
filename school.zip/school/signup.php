<?php include('inc/header.php'); ?>
<div class="col-lg-6">
	<form action="signupcheck.php" method="post">
		<table class="table">
			<legend>Signup page</legend>
			
			<tbody>
				<tr>
					<td>
						<input type="text"  class="form-control" name="username" placeholder="Enter username">
					</td>
				</tr>
				<tr>
					<td>
						<input type="password"  class="form-control" name="password" placeholder="Enter password">
					</td>
				</tr>
				<tr>
					<td>
						<input type="text"  class="form-control" name="firstname" placeholder="Enter firstname">
					</td>
				</tr>
				<tr>	
					<td>
						<input type="text"  class="form-control" name="lastname" placeholder="Enter lastname">
					</td>
				</tr>
				<tr>
					<td>
						<select name="usertype" id="" class="form-control">
							<option value="0">Selct usertype</option>
							<option value="student">Student</option>
							<option value="teacher">Teacher</option>
						</select>
					</td>
				</tr>
				<tr>
					<td>
						<input type="submit" name="submit" value="Submit" class="btn btn-primary">
					</td>
				</tr>
			</tbody>
		</table>
	</form>
</div>
<?php include('inc/footer.php'); ?>