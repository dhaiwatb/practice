<?php

$username = "root";
$password = "root";
$database = "school";
$host = "localhost";

$conn = new mysqli($host,$username,$password,$database) or die();
