<?php

include('inc/database.php');
//echo "<pre>";
//print_r($_POST);

if(isset($_POST['submit']))
{
	$username = $_POST['username'];
	$password = $_POST['password'];
	$firstname = $_POST['firstname'];
	$lastname = $_POST['lastname'];
	$usertype = $_POST['usertype'];

	//$query = "insert into users (username,password,firstname,lastname,usertype) values (?,?,?,?,?)";

	$sql = $conn->prepare("insert into users (username,password,firstname,lastname,usertype) values (?,?,?,?,?);");

	$sql->bind_param('sssss',$username,$password,$firstname,$lastname,$usertype);

	$sql->execute();

	if($sql->affected_rows)
	{
		print_r($sql);
	}
	else
	{
		echo "<pre>";
		print_r($sql);
		echo "Query is not runnable";
	}
}