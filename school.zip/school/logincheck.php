<?php

include('inc/database.php');

$username = $_POST['username'];
$password = $_POST['password'];
$usertype = $_POST['usertype'];



if(isset($_POST['submit']))
{
	//$query = "select * from users where username = ? and password = ? and usertype = ?"; 
	$result = $conn->prepare("select * from users where username = ? and password = ? and usertype = ?;");

	$result->bind_param('sss',$username,$password,$usertype);

	$result->execute();

	if($result->num_rows)
	{
		print_r($result);
	}
	else
	{
		echo "<pre>";
		print_r($result);
		echo "query is not runnable";
	}
}