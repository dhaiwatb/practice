<?php include('database.php'); ?>
<?php

$username = $_POST['username'];
$password = $_POST['password'];
$firstname = $_POST['fname'];
$lastname = $_POST['lname'];
$usertype = $_POST['usertype'];

//print_r($_POST);

if($usertype == "")
{
    header('location:signup.php?error=butype');
}
elseif($_POST['username'])
{
    if($usertype == "student")
    {
        $table = "student_master";
    }
    elseif($usertype = "teacher")
    {
        $table = "teacher_master";    
    }

    $query = "insert into $table (uname,pword,fname,lname) values ('".$username."','".$password."','".$firstname."','".$lastname."')";

    try
    {
        $result = $conn->query($query);
    }
    catch(Exception $e)
    {
        echo $e->getMessage();
    }
}