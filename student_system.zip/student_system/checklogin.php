<?php

include('database.php');

#echo "<pre>";
#print_r($_POST);

$username = $_POST['username'];
$password = $_POST['password'];

if($_POST['username'])
{
    $query = "select * from $table where uname='".$username."' and pword='".$password."'";
    $result = $conn->query($query);

    $totalRows = $result->num_rows;

    $row = $result->fetch_object();
    if($totalRows<1)
    {        
        header("location:login.php?error=nouser");
    }
    else
    {
        session_start();
        $_SESSION['username'] = $row->uname;
        $_SESSION['id'] = $row->id;
        header("location:index.php?id=".$row->id);
    }    
}
elseif($username == "")
{
    header("location:login.php?error=buser");
}
elseif ($password == "") 
{
    header("location:login.php?error=bpassword");
}
elseif($password == "" || $username == "")
{
    header("location:login.php?error=emptyfields");
}