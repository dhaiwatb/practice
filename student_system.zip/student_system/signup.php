<?php include('header.php'); ?>

<?php include('signuperror.php'); ?>

<div class="col-lg-12">
    <div class="row">
        <p class="text-danger"><?=$error_string?></p>
    </div>
    <div class="row">
        <form action="checksignup.php" class="form" method="post">
            <table class="table">
                <legend>Signup User</legend>
                <tr>
                    <td>
                        <input type="text" name="username" value="<?php echo isset($_POST['username'])?$_POST['username']:''?>" placeholder="Username" class="form-control">
                    </td>
                    <td></td>
                </tr>
                <tr>
                    <td>
                        <input type="password" name="password" value="<?php echo isset($_POST['password'])?$_POST['password']:''?>" placeholder="Password" class="form-control">
                    </td>
                    <td></td>
                </tr>
                <tr>
                    <td><input type="text" name="fname" value="<?php echo isset($_POST['fname'])?$_POST['fname']:''?>" placeholder="Firstname" class="form-control"></td>
                    <td></td>
                </tr>
                <tr>
                    <td><input type="text" name="lname" value="<?php echo isset($_POST['lname'])?$_POST['lname']:''?>" placeholder="Lastname" class="form-control"></td>
                    <td></td>
                </tr>
                <tr>
                    <td>
                        <select name="usertype" id="" class="form-control">
                            <option value="" selected="selected">Select User</option>
                            <option value="student">Student</option>
                            <option value="teacher">Teacher</option>
                        </select>
                    </td>
                    <td></td>
                </tr>
                <tr>
                    <td colspan="2"> 
                        <input type="submit" name="submit" value="Submit" class="btn btn-primary">
                        <input type="reset" name="reset" value="Reset" class="btn btn-default">
                    </td>
                </tr>
            </table>
        </form>
    </div>
</div>

<?php include('footer.php'); ?>