<?php include('header.php'); 
    //session_start();
?>
<?php if(isset($_SESSION['username'])): ?>
    <p><?=''?></p>
<?php   else: ?>
    <p>No User available</p>
   
<?php endif; ?>
<?php include('footer.php');  ?>