</div>
</body>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js" type="javascript"></script>
<script src="https://bootswatch.com/_vendor/bootstrap/dist/js/bootstrap.min.js" type="javascript"></script>
<script src="https://bootswatch.com/_assets/js/custom.js" type="javascript"></script>
<script src="asset/js/cust.js" type="javascript"></script>
</html>