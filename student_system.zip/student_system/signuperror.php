<?php
if(isset($_GET['error']))
{
    //usertype not selected
    if($_GET['error'] == "butype")
    {
        $error_string = "Select Usertype";
    }
    //username blank
    elseif($_GET['error'] == "buname")
    {
        $error_string = "Enter Username";
    }
    //password blank
    elseif($_GET['error'] == "bpword")
    {
        $error_string = "Enter Password";
    }
    //firstname blank
    elseif($_GET['error'] == "fname")
    {
        $error_string = "Enter Firstname";
    }
    //lastname blank
    elseif($_GET['error'] == "lname")
    {
        $error_string = "Enter lastname";
    }
    //user not available
    elseif($_GET['error'] == "nouser")
    {
        $error_string = "User not available";
    }
}