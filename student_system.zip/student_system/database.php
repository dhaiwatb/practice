<?php

$host = "localhost";
$username = "root";
$password = "root";
$database = "student_info_system";
$table = "student_master";

$conn = new mysqli($host,$username,$password,$database) or die('Connection failed!');