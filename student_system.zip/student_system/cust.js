$( document ).load(function() {
    console.log( "ready!" );
});

//$('#username').