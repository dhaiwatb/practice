<?php include('header.php'); ?>

<?php  include('loginerror'); ?>

<div class="col-lg-12">
	<div class="row">
		<p class="error text-danger"><?=$error_string?></p>
	</div>
	<div class="row">
		<form action="checklogin.php" method="post">
			<table class="table">
			<legend>Student Login</legend>
				<tr>
					<td><input type="text" name="username" id="username" class="form-control" value="<?php echo isset($_POST['username']) ? $_POST['username'] : '' ?>"></td>
					<td></td>
				</tr>
				<tr>
					<td><input type="password" name="password" id="password" class="form-control" value="<?php echo isset($_POST['password']) ? $_POST['password'] : '' ?>"></td>
					<td></td>
				</tr>
				<tr>
					<td>
						<select name="usertype" id="usertype" class="form-control">
							<option value="student">Student</option>
							<option value="teacher">Teacher</option>
						</select>
					</td>
					<td></td>
				</tr>
				<tr>
					<td>
						<input type="submit" name="submit" value="Submit" class="btn btn-primary">
						<input type="reset" name="reset" value="Reset" class="btn btn-default">
					</td>
					<td></td>
				</tr>
				<tr>
					<td></td>
					<td></td>
				</tr>
			</table>			
		</form>	
	</div>
</div>

<?php include('footer.php'); ?>