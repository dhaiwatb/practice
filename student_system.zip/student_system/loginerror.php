<?php
if(isset($_GET['error']))
{
    //user not available
    if($_GET['error'] == "nouser")
    {
        $error_string = "User not available";
    }
    //username blank
    elseif($_GET['error'] == "buname")
    {
        $error_string = "Enter Username";
    }
    //password blank
    elseif($_GET['error'] == "bpword")
    {
        $error_string = "Enter Password";
    }
}