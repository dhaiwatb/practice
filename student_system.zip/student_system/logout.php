<?php session_start(); ?>
<?php 
if($_SESSION)
{
    session_destroy(); 
    header("location:index.php");
}
?>