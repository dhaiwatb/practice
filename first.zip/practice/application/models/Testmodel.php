<?php

class Testmodel extends CI_Model{
	public function retData()
	{
		return ['xyz'=>"XYZ",'abc'=>"ABC"];
	}
	public function retFromDb()
	{
		$q = $this->db->where('id',1)
						->get('users');

		if($q->num_rows())	
			return $q->result_array();
		else
			echo "no record found";
	}
}