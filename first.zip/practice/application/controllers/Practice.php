<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Practice extends CI_Controller {
	public function index()
	{
		
		$this->load->model('testmodel');

		$data['users'] = $this->testmodel->retFromDb();

		$this->load->view('practicePage',$data);	
		//print_r($data);
	}
	public function testPage()
	{

		echo "this is test page";
	}
}