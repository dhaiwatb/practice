<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Hello world</title>
</head>
<body>
	<table>
		<?php 	
			foreach ($users as $user){
				echo "<tr><td>Username: ".$user['uname']."</td><td>Password: ".$user['pword']."</td>";
			} 
		?>
	</table>
</body>
</html>